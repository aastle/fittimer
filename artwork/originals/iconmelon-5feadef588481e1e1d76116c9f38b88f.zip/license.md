2013 Adam Whitcroft legomushroom@gmail.com http://adamwhitcroft.com/batch/ 
CC by 3.0 http://creativecommons.org/licenses/by/3.0/ 

